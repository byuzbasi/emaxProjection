## ----dictionary, echo=FALSE---------------------------------------------------
dictionary <- data.frame(
  File = c(rep("Dose summary", 4), rep("Interval results", 5)),
  Field = c("dose", "n", "mean", "sd", "method / label", "status", "estimate / qhat", "lower / upper / width", "calibration"),
  Meaning = c("Ordered dose code, 0 through 4; not a physical dose",
    "Number of released observations at that dose",
    "Sample mean of the released response",
    "Sample standard deviation with denominator n - 1",
    "Recorded method identifier and display label",
    "Recorded numerical status",
    "Common fitted target estimate and shape estimate",
    "Reported interval endpoints and width in response units",
    "Description of the method's calibration"))
knitr::kable(dictionary)

