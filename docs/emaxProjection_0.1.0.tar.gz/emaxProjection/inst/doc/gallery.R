## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 6.4, fig.height = 3.8)
library(emaxProjection)

## ----shape-gallery, fig.cap="Illustration: linear, curved, and immediate-saturation shapes. The saturation baseline remains zero."----
x <- seq(0, 1, length.out = 201)
q <- c(0, 0.75, 1)
curves <- sapply(q[1:2], function(shape) emax_response(x, 0, 1, shape, D = 1))
matplot(x, curves, type = "l", lty = c(1, 2), lwd = 2,
  col = c("#142C3B", "#167D8D"),
  xlab = "Normalized dose", ylab = "Excess response", bty = "l")
segments(0, 1, 1, 1, lty = 3, lwd = 2, col = "#9C772B")
points(0, 1, pch = 1, col = "#9C772B")
points(0, 0, pch = 16, col = "#9C772B")
legend("bottomright", c("Linear: q = 0", "Curved: q = 0.75", "Saturation: q = 1"),
  lty = c(1, 2, 3), lwd = 2, col = c("#142C3B", "#167D8D", "#9C772B"), bty = "n")

## ----clinical-table-----------------------------------------------------------
path <- system.file("extdata", "clinical_intervals.tsv", package = "emaxProjection")
intervals <- read.delim(path)
knitr::kable(intervals[c("label", "lower", "upper")], digits = 6,
  col.names = c("Method", "Lower", "Upper"))

## ----clinical-gallery, fig.height=4, fig.cap="Reported code-axis intervals from the completed clinical analysis. The common point estimate is shown as a diamond."----
old_par <- par(mar = c(4.5, 9, 1, 1))
order <- rev(seq_len(nrow(intervals)))
plot(NA, xlim = range(c(0, intervals$lower, intervals$upper)),
  ylim = c(0.5, nrow(intervals) + 0.5), yaxt = "n", bty = "l",
  xlab = "Average excess response on the coded dose axis", ylab = "")
axis(2, at = order, labels = intervals$label, las = 1, cex.axis = 0.8)
segments(intervals$lower, order, intervals$upper, order,
  col = c("#167D8D", rep("#142C3B", nrow(intervals) - 1)), lwd = 2)
points(intervals$lower, order, pch = 16)
points(intervals$upper, order, pch = 16)
points(intervals$estimate, order, pch = 18, col = "#9C772B", cex = 1.2)
abline(v = 0, lty = 3, col = "grey60")
par(old_par)

## ----clinical-reproduction----------------------------------------------------
summary_path <- system.file("extdata", "clinical_dose_summary.tsv", package = "emaxProjection")
summary <- read.delim(summary_path)
variance <- sum((summary$n - 1) * summary$sd^2) / (sum(summary$n) - nrow(summary))
region <- emax_region_from_summary(summary$dose, summary$n, summary$mean,
  pooled_variance = variance, D = 4, calibration = "contrast")
clinical_result <- emax_project(region)
clinical_result
primary <- intervals[intervals$method == "contrast_projection_v1", ]
stopifnot(max(abs(clinical_result$interval - c(primary$lower, primary$upper))) < 1e-8)

