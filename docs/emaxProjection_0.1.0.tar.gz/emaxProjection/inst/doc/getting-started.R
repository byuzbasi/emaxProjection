## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 6, fig.height = 3.5)
library(emaxProjection)

## ----raw-example--------------------------------------------------------------
x <- rep(c(0, 0.5, 1), each = 4)
y <- rep(c(0.2, 0.6, 0.8), each = 4) + rep(c(-0.1, 0.1, -0.2, 0.2), 3)
region <- emax_region(x, y, D = 1, calibration = "contrast")
result <- emax_project(region)
result

## ----summary-example----------------------------------------------------------
summary_region <- emax_region_from_summary(
  region$x, region$counts, region$means, region$pooled_variance,
  D = region$D, calibration = "contrast"
)
stopifnot(isTRUE(all.equal(result$interval, emax_project(summary_region)$interval)))

## ----diagnostics--------------------------------------------------------------
result[c("status", "converged", "termination", "endpoint_gaps", "width_bounds")]
plot(result)

## ----calibrations-------------------------------------------------------------
mean_region <- emax_region(x, y, D = 1, calibration = "mean")
mean_result <- emax_project(mean_region)
knitr::kable(data.frame(
  calibration = c("Contrast", "Full mean region"),
  lower = c(result$interval[1], mean_result$interval[1]),
  upper = c(result$interval[2], mean_result$interval[2])
), digits = 5)

